let truckX = -100; // Posição inicial do caminhão
let truckSpeed = 2; // Velocidade do caminhão
let cows = []; // Array para armazenar os bois

function setup() {
  createCanvas(800, 400);
  // Inicializa os bois com posições aleatórias no campo
  for (let i = 0; i < 5; i++) {
    cows.push({
      x: random(50, 750),
      y: random(320, 370),
      speed: random(0.5, 1.5)
    });
  }
}

function draw() {
  background(135, 206, 235); // Céu azul claro

  drawSun();
  drawMountains();
  drawFields();
  drawRoad();
  drawFarm();
  drawCity();
  drawTruck(truckX, 260);
  drawCows();

  // Atualiza a posição do caminhão
  truckX += truckSpeed;
  if (truckX > width + 100) {
    truckX = -100; // Reinicia a posição quando sai da tela
  }

  // Atualiza a posição dos bois
  for (let cow of cows) {
    cow.x += cow.speed;
    if (cow.x > width) {
      cow.x = -50; // Reinicia a posição quando sai da tela
    }
  }
}

// Sol
function drawSun() {
  fill(255, 204, 0);
  noStroke();
  ellipse(100, 80, 80, 80);
}

// Montanhas
function drawMountains() {
  fill(169, 169, 169);
  triangle(200, 300, 300, 100, 400, 300);
  triangle(300, 300, 450, 120, 600, 300);
}

// Campos com plantações de milho
function drawFields() {
  fill(34, 139, 34);
  rect(0, 300, 800, 100); // Campo verde

  // Fileiras de milho
  for (let x = 50; x < 750; x += 50) {
    drawCorn(x, 320);
  }
}

// Função para desenhar uma planta de milho
function drawCorn(x, y) {
  fill(255, 215, 0); // Amarelo
  ellipse(x, y, 10, 30);
  fill(0, 100, 0); // Verde escuro
  triangle(x - 5, y, x, y - 20, x + 5, y);
}

// Estrada
function drawRoad() {
  fill(50);
  rect(0, 280, 800, 20); // Estrada

  // Faixas da estrada
  stroke(255);
  strokeWeight(2);
  for (let x = 0; x < width; x += 40) {
    line(x, 290, x + 20, 290);
  }
  noStroke();
}

// Fazenda com casa e árvores
function drawFarm() {
  // Casa
  fill(210, 180, 140); // Cor da casa
  rect(100, 240, 60, 40);
  fill(139, 69, 19); // Telhado
  triangle(100, 240, 130, 210, 160, 240);

  // Árvores
  drawTree(50, 250);
  drawTree(180, 250);
}

// Função para desenhar uma árvore
function drawTree(x, y) {
  fill(139, 69, 19); // Tronco
  rect(x, y, 10, 30);
  fill(34, 139, 34); // Copa
  ellipse(x + 5, y, 30, 30);
}

// Cidade com prédios
function drawCity() {
  let baseY = 200;
  for (let i = 0; i < 5; i++) {
    let x = 500 + i * 50;
    let h = 80;
    fill(169, 169, 169);
    rect(x, baseY - h, 40, h);
    // Janelas
    fill(255);
    for (let y = baseY - h + 10; y < baseY; y += 20) {
      rect(x + 10, y, 10, 10);
    }
  }
}

// Caminhão na estrada
function drawTruck(x, y) {
  fill(255, 0, 0); // Vermelho
  rect(x, y, 60, 20); // Carroceria
  fill(0, 0, 255); // Azul
  rect(x + 60, y + 10, 20, 10); // Cabine
  fill(0); // Rodas
  ellipse(x + 10, y + 20, 10, 10);
  ellipse(x + 70, y + 20, 10, 10);
}

// Função para desenhar os bois
function drawCows() {
  for (let cow of cows) {
    drawCow(cow.x, cow.y);
  }
}

// Função para desenhar um boi
function drawCow(x, y) {
  // Corpo
  fill(255); // Branco
  rect(x, y, 30, 20);
  // Cabeça
  rect(x - 15, y + 5, 15, 10);
  // Pernas
  rect(x + 5, y + 20, 5, 10);
  rect(x + 20, y + 20, 5, 10);
  // Chifres
  stroke(0);
  line(x - 10, y + 5, x - 15, y);
  line(x - 5, y + 5, x - 10, y);
  noStroke();
}